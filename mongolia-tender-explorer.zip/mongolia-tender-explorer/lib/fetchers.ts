import * as cheerio from "cheerio";
import { mockData } from "./mock";
import { TenderApiResponse, TenderRecord } from "./types";

const USER_BASE_EN = "https://user.tender.gov.mn/en/invitation";
const USER_BASE_MN = "https://user.tender.gov.mn/mn/invitation";
const OPEN_API_BASE = "https://opendata.tender.gov.mn/api/invitation";

function safeNumber(value: unknown): number | string | null {
  if (value === null || value === undefined || value === "") return null;
  const cleaned = String(value).replace(/,/g, "").trim();
  const n = Number(cleaned);
  return Number.isNaN(n) ? cleaned : n;
}

function normalizeOpenApiItem(item: Record<string, unknown>): TenderRecord {
  const id = String(item.invitationId ?? item.id ?? "");
  return {
    id,
    invitationNumber: String(item.invitationNumber ?? ""),
    tenderCode: String(item.tenderCode ?? ""),
    tenderName: String(item.tenderName ?? ""),
    budgetGovernorName: String(item.budgetGovernerName ?? item.budgetGovernorName ?? ""),
    budgetEntityName: String(item.budgetEntityName ?? ""),
    tenderTypeName: String(item.tenderTypeName ?? ""),
    fundName: String(item.fundName ?? ""),
    ruleName: String(item.ruleName ?? ""),
    totalBudget: safeNumber(item.totalBudget),
    yearBudget: safeNumber(item.yearBudget),
    publishDate: String(item.publishDate ?? ""),
    receiveDate: String(item.receiveDate ?? ""),
    openDate: String(item.openDate ?? ""),
    docStatusName: String(item.docStatusName ?? ""),
    isSimpleElectronic: Boolean(item.isSimpleElectronic),
    detailUrl: id ? `https://user.tender.gov.mn/en/invitation/detail/${id}` : undefined
  };
}

async function fetchFromOpenApi(params: {
  year: number;
  page: number;
  perPage: number;
  query?: string;
}): Promise<TenderApiResponse> {
  const token = process.env.TENDER_GOV_TOKEN;
  if (!token) throw new Error("Missing TENDER_GOV_TOKEN");

  const search = new URLSearchParams({
    page: String(params.page),
    perpage: String(params.perPage),
    year: String(params.year),
    get: "1"
  });
  if (params.query) search.set("keyword", params.query);

  const res = await fetch(`${OPEN_API_BASE}?${search.toString()}`, {
    headers: { Authorization: `Bearer ${token}` },
    next: { revalidate: 3600 }
  });

  if (!res.ok) {
    throw new Error(`Open API request failed (${res.status})`);
  }

  const json = await res.json();
  const rawItems = Array.isArray(json?.data) ? json.data : Array.isArray(json) ? json : [];
  const total = Number(json?.total ?? json?.count ?? rawItems.length ?? 0);

  return {
    total,
    page: params.page,
    perPage: params.perPage,
    year: params.year,
    source: "open-api",
    items: rawItems.map(normalizeOpenApiItem)
  };
}

function parseDateish(text: string): string {
  const trimmed = text.trim();
  return trimmed;
}

function parseHtmlRows(html: string, pageUrl: string, year: number, page: number, perPage: number): TenderApiResponse {
  const $ = cheerio.load(html);
  const rows = $("table tbody tr");
  const items: TenderRecord[] = [];

  rows.each((_, row) => {
    const cells = $(row).find("td");
    if (cells.length === 0) return;

    const link = $(row).find('a[href*="/invitation/detail/"]').first();
    const href = link.attr("href") || "";
    const idMatch = href.match(/detail\/(\d+)/);
    const id = idMatch?.[1] || href || `row-${items.length + 1}`;
    const textCells = cells.map((__, cell) => $(cell).text().replace(/\s+/g, " ").trim()).get();

    items.push({
      id,
      invitationNumber: textCells[0] || undefined,
      tenderCode: textCells[1] || undefined,
      tenderName: textCells[2] || link.text().trim() || undefined,
      budgetEntityName: textCells[3] || undefined,
      tenderTypeName: textCells[4] || undefined,
      fundName: textCells[5] || undefined,
      totalBudget: safeNumber(textCells[6]),
      publishDate: parseDateish(textCells[7] || ""),
      receiveDate: parseDateish(textCells[8] || ""),
      openDate: parseDateish(textCells[9] || ""),
      docStatusName: textCells[10] || undefined,
      detailUrl: href ? new URL(href, pageUrl).toString() : undefined
    });
  });

  const paginationText = $.text();
  const totalMatch = paginationText.match(/(?:Total|Нийт)\s*[:：]?\s*(\d{1,9})/i);
  const total = totalMatch ? Number(totalMatch[1]) : items.length;

  return {
    total,
    page,
    perPage,
    year,
    source: "public-html",
    warning: items.length === 0 ? "The HTML parser did not find any rows. The site layout may have changed; inspect the source HTML and update selectors in lib/fetchers.ts." : undefined,
    items
  };
}

async function fetchFromPublicHtml(params: {
  year: number;
  page: number;
  perPage: number;
  query?: string;
}): Promise<TenderApiResponse> {
  const search = new URLSearchParams({
    year: String(params.year),
    page: String(params.page),
    perpage: String(params.perPage),
    get: "1"
  });

  if (params.query) {
    search.set("keyword", params.query);
  }

  const candidates = [`${USER_BASE_EN}?${search.toString()}`, `${USER_BASE_MN}?${search.toString()}`];
  let lastError: unknown;

  for (const url of candidates) {
    try {
      const res = await fetch(url, {
        headers: {
          "user-agent": "Mozilla/5.0"
        },
        next: { revalidate: 3600 }
      });
      if (!res.ok) throw new Error(`Public page failed (${res.status})`);
      const html = await res.text();
      return parseHtmlRows(html, url, params.year, params.page, params.perPage);
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError instanceof Error ? lastError : new Error("Public HTML fetch failed");
}

export async function getTenders(params: {
  year: number;
  page: number;
  perPage: number;
  query?: string;
  forceSource?: "mock" | "open-api" | "public-html";
}): Promise<TenderApiResponse> {
  const { forceSource, year, page, perPage, query } = params;

  if (forceSource === "mock") return mockData(year, page, perPage);
  if (forceSource === "open-api") return fetchFromOpenApi({ year, page, perPage, query });
  if (forceSource === "public-html") return fetchFromPublicHtml({ year, page, perPage, query });

  try {
    return await fetchFromOpenApi({ year, page, perPage, query });
  } catch {
    try {
      return await fetchFromPublicHtml({ year, page, perPage, query });
    } catch {
      return mockData(year, page, perPage);
    }
  }
}
